/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'he', {
	fontSize: {
		label: 'גודל',
		voiceLabel: 'גודל',
		panelTitle: 'גודל'
	},
	label: 'גופן',
	panelTitle: 'גופן',
	voiceLabel: 'גופן'
} );
