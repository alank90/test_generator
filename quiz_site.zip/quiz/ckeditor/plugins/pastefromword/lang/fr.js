/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'fr', {
	confirmCleanup: 'Le texte à coller semble provenir de Word. Désirez-vous le nettoyer avant de coller?',
	error: 'Il n\'a pas été possible de nettoyer les données collées à la suite d\'une erreur interne.',
	title: 'Coller depuis Word',
	toolbar: 'Coller depuis Word'
} );
