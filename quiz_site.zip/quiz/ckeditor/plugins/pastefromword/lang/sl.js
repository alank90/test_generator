/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'sl', {
	confirmCleanup: 'Besedilo, ki ga želite prilepiti je kopirano iz Word-a. Ali ga želite očistiti, preden ga prilepite?',
	error: 'Ni bilo mogoče očistiti prilepljenih podatkov zaradi notranje napake',
	title: 'Prilepi iz Worda',
	toolbar: 'Prilepi iz Worda'
} );
