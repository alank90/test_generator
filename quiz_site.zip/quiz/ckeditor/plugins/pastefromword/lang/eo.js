/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'eo', {
	confirmCleanup: 'La teksto, kiun vi volas interglui, ŝajnas esti kopiita el Word. Ĉu vi deziras purigi ĝin antaŭ intergluo?',
	error: 'Ne eblis purigi la intergluitajn datenojn pro interna eraro',
	title: 'Interglui el Word',
	toolbar: 'Interglui el Word'
} );
